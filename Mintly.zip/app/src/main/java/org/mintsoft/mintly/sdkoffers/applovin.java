package org.mintsoft.mintly.sdkoffers;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.applovin.adview.AppLovinIncentivizedInterstitial;
import com.applovin.sdk.AppLovinAd;
import com.applovin.sdk.AppLovinAdDisplayListener;
import com.applovin.sdk.AppLovinAdLoadListener;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkSettings;

import org.mintsoft.mintly.helper.Misc;
import org.mintsoft.mintly.offers.Offers;

import java.util.HashMap;

public class applovin extends Activity {
    private ProgressDialog dialog;
    private AppLovinIncentivizedInterstitial myIncent;
    private AppLovinAdDisplayListener listener;
    private AppLovinSdk.SdkInitializationListener sdkInitializationListener;
    private AppLovinSdk instance;

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Intent intent = getIntent();
        HashMap<String, String> data = Misc.convertToHashMap(intent, "info");
        String user = intent.getStringExtra("user");
        if (data != null && user != null) {
            showDialog();
            AppLovinSdkSettings settings = new AppLovinSdkSettings();
            settings.setVerboseLogging(false);
            instance = AppLovinSdk.getInstance(data.get("sdk_key"), new AppLovinSdkSettings(), this);
            instance.setUserIdentifier(user);
            sdkInitializationListener = config -> {
                myIncent = AppLovinIncentivizedInterstitial.create(instance);
                listener = new AppLovinAdDisplayListener() {
                    @Override
                    public void adDisplayed(AppLovinAd ad) {

                    }

                    @Override
                    public void adHidden(AppLovinAd ad) {
                        myIncent.preload(null);
                        finish();
                    }
                };
                myIncent.preload(new AppLovinAdLoadListener() {
                    @Override
                    public void adReceived(AppLovinAd appLovinAd) {
                        if (dialog.isShowing()) dialog.dismiss();
                        myIncent.show(appLovinAd, applovin.this, null,
                                null, listener, null);
                        Offers.checkBalance = true;
                    }

                    @Override
                    public void failedToReceiveAd(int errorCode) {
                        if (dialog.isShowing()) dialog.dismiss();
                        uiToast("Error code: " + errorCode);
                        finish();
                    }
                });
            };
            instance.initializeSdk(sdkInitializationListener);
        } else {
            finish();
        }
    }

    private void showDialog() {
        dialog = Misc.customProgress(this);
        dialog.show();
    }

    private void uiToast(final String toast) {
        runOnUiThread(() -> Toast.makeText(applovin.this, toast, Toast.LENGTH_LONG).show());
    }

    protected void onDestroy() {
        listener = null;
        myIncent = null;
        sdkInitializationListener = null;
        super.onDestroy();
    }
}
