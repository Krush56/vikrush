package org.mintsoft.mintly.sdkoffers;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.rewarded.ServerSideVerificationOptions;

import org.mintsoft.mintly.helper.Misc;
import org.mintsoft.mintly.offers.Offers;

import java.util.HashMap;
import java.util.Objects;

public class admob extends Activity {
    private ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Intent intent = getIntent();
        HashMap<String, String> data = Misc.convertToHashMap(intent, "info");
        String user = intent.getStringExtra("user");
        if (data != null && user != null) {
            dialog = Misc.customProgress(this);
            dialog.show();
            AdRequest adRequest = new AdRequest.Builder().build();
            RewardedAd.load(this, Objects.requireNonNull(data.get("rewarded_slot")),
                    adRequest, new RewardedAdLoadCallback() {
                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            dialog.dismiss();
                            uiToast("" + loadAdError.getMessage());
                            finish();
                        }

                        @Override
                        public void onAdLoaded(@NonNull RewardedAd ad) {
                            dialog.dismiss();
                            ServerSideVerificationOptions options = new ServerSideVerificationOptions.Builder().setUserId(user).build();
                            ad.setServerSideVerificationOptions(options);
                            ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                                @Override
                                public void onAdShowedFullScreenContent() {
                                }

                                @Override
                                public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                                    uiToast("" + adError.getMessage());
                                }

                                @Override
                                public void onAdDismissedFullScreenContent() {
                                    finish();
                                }
                            });
                            ad.show(admob.this, rewardItem -> {
                                Offers.checkBalance = true;
                            });
                        }
                    });
        } else {
            finish();
        }
    }

    private void uiToast(final String toast) {
        runOnUiThread(() -> Toast.makeText(admob.this, toast, Toast.LENGTH_LONG).show());
    }
}