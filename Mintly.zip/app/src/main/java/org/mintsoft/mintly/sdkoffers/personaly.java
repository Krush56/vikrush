package org.mintsoft.mintly.sdkoffers;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import org.mintsoft.mintly.helper.Misc;
import org.mintsoft.mintly.offers.Offers;

import java.util.HashMap;

import ly.persona.sdk.OfferWallAd;
import ly.persona.sdk.Personaly;
import ly.persona.sdk.listener.AdListener;

public class personaly extends Activity {
    private ProgressDialog dialog;
    private Personaly.InitCallback initCallback;
    private AdListener adListener;

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Intent intent = getIntent();
        HashMap<String, String> data = Misc.convertToHashMap(intent, "info");
        String user = intent.getStringExtra("user");
        if (data != null && user != null) {
            showDialog();
            try {
                Personaly.CONFIG.setUserId(user);
                adListener = new AdListener() {
                    @Override
                    public void onAdStartLoading() {
                        if (dialog.isShowing()) dialog.dismiss();
                    }

                    @Override
                    public void onAdFailed(Throwable throwable) {
                        if (dialog.isShowing()) dialog.dismiss();
                        uiToast(personaly.this, "" + throwable.getMessage());
                        finish();
                    }
                };
                initCallback = new Personaly.InitCallback() {
                    @Override
                    public void onSuccess() {
                        OfferWallAd.get(data.get("placement_id")).setListener(adListener).show();
                        Offers.checkBalance = true;
                        finish();
                    }

                    @Override
                    public void onFailure(Throwable throwable) {
                        if (dialog.isShowing()) dialog.dismiss();
                        uiToast(personaly.this, "" + throwable.getMessage());
                        finish();
                    }
                };
                Personaly.init(this, data.get("app_id"), initCallback);
            } catch (Exception e) {
                Toast.makeText(this, "" + e.getMessage(), Toast.LENGTH_LONG).show();
                finish();
            }
        } else {
            finish();
        }
    }

    private void showDialog() {
        dialog = Misc.customProgress(this);
        dialog.show();
    }

    private void uiToast(final Activity context, final String toast) {
        context.runOnUiThread(() -> Toast.makeText(context, toast, Toast.LENGTH_LONG).show());
    }

    @Override
    protected void onDestroy() {
        adListener = null;
        initCallback = null;
        super.onDestroy();
    }
}
