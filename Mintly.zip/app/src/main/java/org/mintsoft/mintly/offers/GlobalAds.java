package org.mintsoft.mintly.offers;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.rewarded.ServerSideVerificationOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.mintsoft.mintlib.GetAuth;
import org.mintsoft.mintlib.GetNet;
import org.mintsoft.mintly.Home;
import org.mintsoft.mintly.R;

import java.util.HashMap;

public class GlobalAds {
    private static RewardedAd rewardedAd;
    private static String uid;

    public static void resume(FloatingActionButton fab) {
        if (Home.rewardedUnit != null) {
            String posStr = Home.spf.getString("fab_pos", null);
            if (posStr != null) {
                String[] pos = posStr.split(",");
                fab.setX(Float.parseFloat(pos[0]));
                fab.setY(Float.parseFloat(pos[1]));
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    public static FloatingActionButton fab(Activity context, String unitName) {
        if (Home.rewardedUnit == null || !Home.fab) return null;
        HashMap<String, String> admobData = GetNet.sdkInfo("infos_cpv",
                "admob", new String[]{unitName, "fab", "fav_iv"});
        String name = admobData.get(unitName);
        if (name == null || !name.equals("yes")) return null;
        FloatingActionButton fab = new FloatingActionButton(context);
        View views = context.findViewById(android.R.id.content);
        ViewGroup rootView = (ViewGroup) ((ViewGroup) views).getChildAt(0);
        rootView.addView(fab);
        fab.post(() -> fab.setVisibility(View.GONE));
        try {
            fab.setImageResource(R.drawable.anim_offer);
            fab.setCustomSize(155);
            fab.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#1171a5")));
            //fab.setBackgroundTintList(ColorStateList.valueOf(Color.WHITE));
            fab.setScaleType(ImageView.ScaleType.CENTER);
            fab.post(() -> {
                AnimationDrawable frameAnimation = (AnimationDrawable) fab.getDrawable();
                frameAnimation.start();
            });
            String posStr = Home.spf.getString("fab_pos", null);
            if (posStr == null) {
                views.getViewTreeObserver().addOnGlobalLayoutListener(
                        new ViewTreeObserver.OnGlobalLayoutListener() {
                            @Override
                            public void onGlobalLayout() {
                                int x = views.getWidth() - fab.getWidth() - views.getWidth() / 18;
                                int y = views.getHeight() - fab.getHeight() - views.getHeight() / 28;
                                fab.setX(x);
                                fab.setY(y);
                                Home.spf.edit().putString("fab_pos", x + "," + y).apply();
                                views.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                            }
                        });
            } else {
                String[] pos = posStr.split(",");
                fab.setX(Float.parseFloat(pos[0]));
                fab.setY(Float.parseFloat(pos[1]));
            }
            fab.setOnLongClickListener(v -> {
                v.setOnTouchListener((view, event) -> {
                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_MOVE:
                            view.setX(event.getRawX() - 60);
                            view.setY(event.getRawY() - 100);
                            break;
                        case MotionEvent.ACTION_UP:
                            view.setOnTouchListener(null);
                            Home.spf.edit().putString("fab_pos", (event.getRawX() - 60)
                                    + "," + (event.getRawY() - 100)).apply();
                            break;
                        default:
                            break;
                    }
                    return true;
                });
                return true;
            });
            uid = GetAuth.user(context);
            if (rewardedAd == null) {
                load(context, fab);
            } else {
                fab.post(() -> fab.setVisibility(View.VISIBLE));
            }
            fab.setOnClickListener(view -> {
                if (rewardedAd != null) {
                    rewardedAd.show(context, rewardItem -> {
                        int rewardAmount = rewardItem.getAmount();
                        Toast.makeText(context, context.getString(R.string.you_won)
                                + " " + rewardAmount + " " + Home.currency.toLowerCase()
                                + "s", Toast.LENGTH_LONG).show();
                    });
                    rewardedAd = null;
                }
                fab.setVisibility(View.GONE);
            });
        } catch (Exception e) {
            fab.setVisibility(View.GONE);
        }
        return fab;
    }

    private static void load(Activity context, FloatingActionButton fab) {
        if (rewardedAd != null) return;
        context.runOnUiThread(() -> {
            AdRequest adRequest = new AdRequest.Builder().build();
            RewardedAd.load(context.getApplicationContext(), Home.rewardedUnit,
                    adRequest, new RewardedAdLoadCallback() {
                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            fab.setVisibility(View.GONE);
                            Toast.makeText(context, "" + loadAdError.getMessage(), Toast.LENGTH_LONG).show();
                        }

                        @Override
                        public void onAdLoaded(@NonNull RewardedAd ad) {
                            ad.setServerSideVerificationOptions(new ServerSideVerificationOptions.Builder().setUserId(uid).build());
                            ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                                @Override
                                public void onAdDismissedFullScreenContent() {
                                    rewardedAd = null;
                                    fab.setVisibility(View.GONE);
                                    new Handler().postDelayed(() -> load(context, fab), Home.fab_iv);
                                }
                            });
                            rewardedAd = ad;
                            fab.setVisibility(View.VISIBLE);
                        }
                    });
        });
    }
}