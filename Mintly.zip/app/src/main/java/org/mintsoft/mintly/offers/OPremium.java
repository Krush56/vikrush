package org.mintsoft.mintly.offers;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import org.mintsoft.mintlib.Customoffers;
import org.mintsoft.mintlib.Tracker;
import org.mintsoft.mintlib.onResponse;
import org.mintsoft.mintly.Home;
import org.mintsoft.mintly.R;
import org.mintsoft.mintly.helper.Misc;
import org.mintsoft.mintly.helper.Variables;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

public class OPremium extends Fragment {
    private Context context;
    private RecyclerView recyclerView;
    private ArrayList<HashMap<String, String>> list;
    private ProgressBar progressBar;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        context = getContext();
        View v = inflater.inflate(R.layout.offers_list, container, false);
        if (context == null || getActivity() == null) return v;
        progressBar = getActivity().findViewById(R.id.offers_progressBar);
        recyclerView = v.findViewById(R.id.offers_list_recyclerView);
        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        recyclerView.setLayoutManager(new GridLayoutManager(context, 2));
        list = Variables.getArrayHash("premium_list");
        if (list == null || Tracker.shouldReload(context)) {
            callnet();
        } else {
            recyclerView.setAdapter(new pAdapter());
        }
    }

    @Override
    public void onResume() {
        if (Tracker.shouldReload(context)) {
            callnet();
        }
        super.onResume();
    }

    @Override
    public void onDestroy() {
        Variables.setArrayHash("premium_list", list);
        super.onDestroy();
    }

    private void callnet() {
        progressBar.setVisibility(View.VISIBLE);
        Customoffers.getCustomOffers(context, new onResponse() {
            @Override
            public void onSuccessHashListHashMap(HashMap<String, ArrayList<HashMap<String, String>>> hashListHashmap) {
                list = new ArrayList<>();
                list.addAll(Objects.requireNonNull(hashListHashmap.get("i")));
                list.addAll(Objects.requireNonNull(hashListHashmap.get("s")));
                recyclerView.setAdapter(new pAdapter());
            }

            @Override
            public void onError(int errorCode, String error) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(context, "Could not connect to the server", Toast.LENGTH_LONG).show();
            }
        });
    }

    private class pAdapter extends RecyclerView.Adapter<pAdapter.ViewHolder> {
        private final LayoutInflater mInflater;
        private final String currency;

        public pAdapter() {
            this.mInflater = LayoutInflater.from(context);
            this.currency = " " + Home.currency.toLowerCase() + "s";
            progressBar.setVisibility(View.GONE);
        }

        @NonNull
        @Override
        public pAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = mInflater.inflate(R.layout.offers_api_grid, parent, false);
            return new pAdapter.ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull pAdapter.ViewHolder holder, int position) {
            holder.titleView.setText(list.get(position).get("title"));
            holder.descView.setText(list.get(position).get("desc"));
            holder.amountView.setText((list.get(position).get("amount") + currency));
            //holder.typeView.setVisibility(View.VISIBLE);
            //holder.typeView.setText(("Install"));
            Picasso.get().load(list.get(position).get("image"))
                    .placeholder(R.drawable.anim_loading)
                    .error(R.color.gray)
                    .into(holder.imageView);
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
            TextView titleView, descView, amountView, typeView;
            ImageView imageView;

            ViewHolder(View itemView) {
                super(itemView);
                titleView = itemView.findViewById(R.id.offers_item_titleView);
                descView = itemView.findViewById(R.id.offers_item_descView);
                amountView = itemView.findViewById(R.id.offers_item_amountView);
                imageView = itemView.findViewById(R.id.offers_item_imageView);
                //typeView = itemView.findViewById(R.id.offers_item_typeView);
                itemView.setOnClickListener(this);
            }

            @Override
            public void onClick(View view) {
                Tracker.openOffer(context, Objects.requireNonNull(list.get(getAdapterPosition()).get("url")), new onResponse() {
                    @Override
                    public void onSuccess(String newUrl) {
                        Misc.onenUrl(context, newUrl);
                    }

                    @Override
                    public void onError(int errorCode, String error) {
                        if (errorCode == 0) {
                            for (int i = 0; i < list.size(); i++) {
                                if (Objects.equals(list.get(i).get("url"), error)) {
                                    remove(i);
                                    break;
                                }
                            }
                        } else {
                            remove(getAdapterPosition());
                            Toast.makeText(context, error, Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        }

        public void remove(int position) {
            list.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, list.size());
        }
    }
}
