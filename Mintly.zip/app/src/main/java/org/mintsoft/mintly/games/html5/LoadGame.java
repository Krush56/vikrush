package org.mintsoft.mintly.games.html5;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.mintsoft.mintly.Home;
import org.mintsoft.mintly.R;
import org.mintsoft.mintly.helper.Misc;

import org.mintsoft.mintlib.hGameInit;
import org.mintsoft.mintlib.onResponse;

public class LoadGame extends AppCompatActivity {
    private ProgressBar progressBar;
    private TextView progressView;
    private String file, title;
    private boolean landscape, na;

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            finish();
        } else {
            file = extras.getString("file", null);
            title = extras.getString("title", "Game loading");
            landscape = extras.getBoolean("landscape", false);
            na = extras.getBoolean("na", true);
            if (file == null) {
                finish();
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                        init();
                    } else {
                        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(this);
                            builder.setTitle("Permission Needed")
                                    .setMessage("Rationale")
                                    .setPositiveButton(android.R.string.ok, (dialog, id) -> ActivityCompat.requestPermissions(
                                            this, new String[]{
                                                    Manifest.permission.READ_EXTERNAL_STORAGE,
                                                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                                            }, 131));
                            builder.create().show();
                        } else {
                            ActivityCompat.requestPermissions(this,
                                    new String[]{
                                            Manifest.permission.READ_EXTERNAL_STORAGE,
                                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                                    }, 131);
                        }
                    }
                } else {
                    init();
                }
            }
        }
    }

    private void init() {
        setContentView(R.layout.game_html_load);
        progressBar = findViewById(R.id.load_game_progressBar);
        progressView = findViewById(R.id.load_game_percentView);
        TextView titleView = findViewById(R.id.load_game_gameNameView);
        titleView.setText(title);
        new hGameInit().get(this, file, Home.spf.getLong("hrl", 24 * 60 * 60 * 1000),
                new onResponse() {
                    @Override
                    public void onSuccess(String response) {
                        if (response == null) {
                            finish();
                        } else {
                            progressBar.setProgress(Integer.parseInt(response));
                            progressView.setText((response + "%"));
                        }
                    }

                    @Override
                    public void onError(int errorCode, String error) {
                        Toast.makeText(LoadGame.this, error, Toast.LENGTH_LONG).show();
                        if (errorCode == -1) finish();
                    }

                    @Override
                    public void onFinish(String response) {
                        Intent intent = Misc.startHtml(LoadGame.this, response, landscape, na);
                        if (!Home.otherUrl) {
                            intent.putExtra("otherurl", "https://" + getString(R.string.domain_name));
                        }
                        startActivity(intent);
                        finish();
                    }
                });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 131) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                init();
            } else {
                finish();
            }
        }
    }

    @Override
    public void onBackPressed() {
    }
}