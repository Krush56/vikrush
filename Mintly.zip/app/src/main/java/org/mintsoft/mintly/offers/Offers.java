package org.mintsoft.mintly.offers;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import org.mintsoft.mintlib.GetAuth;
import org.mintsoft.mintlib.onResponse;
import org.mintsoft.mintly.Home;
import org.mintsoft.mintly.R;

import java.util.HashMap;

public class Offers extends AppCompatActivity {
    public static boolean checkBalance;
    private boolean checking;
    private TextView balView, balText;
    private ViewPager2 viewPager;
    private String[] tabs;
    private final Fragment[] fragments = new Fragment[]{new org.mintsoft.mintly.offers.OSdk(), new org.mintsoft.mintly.offers.OVideo(),
            new org.mintsoft.mintly.offers.OPremium(), new org.mintsoft.mintly.offers.OApi(), new org.mintsoft.mintly.offers.OWeb()};

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.offers);
        balView = findViewById(R.id.offers_balView);
        balText = findViewById(R.id.offers_balText);
        balView.setText(Home.balance);
        pagerAdapter adapter = new pagerAdapter(this);
        viewPager = findViewById(R.id.offers_viewPager);
        viewPager.setAdapter(adapter);
        TabLayout tabLayout = findViewById(R.id.offers_tabLayout);
        tabs = new String[]{getString(R.string.sdk_offerwalls), getString(R.string.video_offers),
                getString(R.string.premium_offers), getString(R.string.api_offerwalls),
                getString(R.string.web_offerwall)
        };
        new TabLayoutMediator(tabLayout, viewPager, (tab, position) -> tab.setText(tabs[position])).attach();
        findViewById(R.id.offers_go_video).setOnClickListener(view -> startActivity(new Intent(Offers.this, org.mintsoft.mintly.offers.Yt.class)));
        findViewById(R.id.offers_back).setOnClickListener(view -> finish());
        findViewById(R.id.offers_checkBal).setOnClickListener(view -> {
            balText.setText(getString(R.string.checking));
            checkBal();
        });
    }

    @Override
    protected void onPostResume() {
        if (checkBalance) {
            checkBalance = false;
            checkBal();
        } else {
            balView.setText(Home.balance);
        }
        super.onPostResume();
    }

    @Override
    public void onBackPressed() {
        if (viewPager.getCurrentItem() == 0) {
            super.onBackPressed();
        } else {
            viewPager.setCurrentItem(viewPager.getCurrentItem() - 1);
        }
    }

    private class pagerAdapter extends FragmentStateAdapter {
        public pagerAdapter(AppCompatActivity fa) {
            super(fa);
        }

        @NonNull
        @Override
        public Fragment createFragment(int pos) {
            return fragments[pos];
        }

        @Override
        public int getItemCount() {
            return fragments.length;
        }
    }

    private void checkBal() {
        if (checking) return;
        checking = true;
        GetAuth.balance(this, Home.spf, new onResponse() {
            @Override
            public void onSuccessHashMap(HashMap<String, String> data1) {
                Home.balance = data1.get("balance");
                balText.setText(getString(R.string.balance));
                balView.setText(Home.balance);
                checking = false;
            }

            @Override
            public void onSuccess(String success) {
                Home.checkNotif = true;
            }

            @Override
            public void onError(int i, String s) {
                super.onError(i, s);
                balText.setText(getString(R.string.balance));
                checking = false;
            }
        });
    }
}